const arthur = {
  nome: "Arthur Fudali",
  idade: 18,
  altura: 171,
  cidade: "Pariquera-Açu",
  artista: "Deftones",
};
console.log(
  `\n Nome: ${arthur.nome}, \n idade: ${arthur.idade}, \n altura: ${arthur.altura}, \n cidade: ${arthur.cidade}, \n artista: ${arthur.artista}`
);
